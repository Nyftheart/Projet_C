#ifndef POTION_H
#define POTION_H

typedef enum { POTION_TYPE } PotionType;
	
	typedef struct Potion
	{
		PotionType type;
		int regen;
	} Potion;



#endif