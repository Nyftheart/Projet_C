#ifndef ROGUE_H
#define ROGUE_H

#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


/************* Global Variables *************/
int MAX_HEIGHT;
int MAX_WIDTH;



#endif