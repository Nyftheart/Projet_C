#include "rogue.h"
#include "main.h"


void Credis()
{
    
    int ch = 'e';
    
    /* main game loop */

        if (ch != 'e')
        {
            menuLoop();
        }
        printw("Credis\n");
        printw("Le BOSSSSSSSSSS PUTAIN : Moi (Alex)\n");
        printw("Le Reale de fous : Yann\n");
        printw("J'ai pas de PC MDR : Mahery\n");


        ch = getch();
        
    

}